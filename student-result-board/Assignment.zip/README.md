# to run server please enter below command

npm install
npm start

# navigate to below route to access students results dashboard

http://localhost:3000/students-results

# navigate to below route to access students registration form

http://localhost:3000/school-admission-form
